﻿using SprayerControl;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArduinoControlApp
{

    public partial class Form1 : Form
    {
        private Keypad.NumKeypad numKeypad; // Declare an instance of NumKeypad
        private TextBox activeTextBox;      // Tracks which text box is currently active for data entry
        private readonly UdpClient udpClient;
        private IPEndPoint arduinoEndPoint;



        public Form1()
        {
            InitializeComponent();
            CmbUnits.SelectedIndex = 0; // Default to "I - Imperial"
            CmbUnits.SelectedIndexChanged += CmbUnits_SelectedIndexChanged;

            numKeypad = new Keypad.NumKeypad
            {
                StartPosition = FormStartPosition.Manual, // Allows us to position the keypad manually
                TopMost = true, // Keeps the keypad on top of Form1
                ShowInTaskbar = false // Prevents it from appearing in the taskbar
            };

            // Subscribe to Click events data entry text boxes
            txtGPATarget.Click += TextBox_Click;
            txtSprayWidth.Click += TextBox_Click;
            txtFlowCalibration.Click += TextBox_Click;
            txtPSICalibration.Click += TextBox_Click;
            txtDutyCycleAdjustment.Click += TextBox_Click;
            txtPressureTarget.Click += TextBox_Click;
            txtnumberNozzles.Click += TextBox_Click;
            txtcurrentDutyCycle.Click += TextBox_Click;
            txtHz.Click += TextBox_Click;
            txtLowBallValve.Click += TextBox_Click;
            txtBall_Hyd.Click += TextBox_Click;
            txtWheelAngle.Click += TextBox_Click;
            txtKp.Click += TextBox_Click;
            txtKi.Click += TextBox_Click;
            txtKd.Click += TextBox_Click;

            // Subscribe to the ButtonPressed event
            numKeypad.ButtonPressed += NumKeypad_ButtonPressed;

            PopulateDebugLevelComboBox();
            Debug.WriteLine("Populated Debug Level ComboBox.");

            // All communicatiion through port 7777
            udpClient = new UdpClient(7777);
            arduinoEndPoint = new IPEndPoint(IPAddress.Parse("192.168.5.123"), 7777);
            Debug.WriteLine($"Initialized arduinoEndPoint: {arduinoEndPoint.Address}:{arduinoEndPoint.Port}");


            StartListening();
        }


        private void TextBox_Click(object sender, EventArgs e)
        {
            if (sender is TextBox textBox)
            {
                if (textBox.ReadOnly || !textBox.Enabled)
                {
                    return; // Ignore non-editable fields
                }

                // Clear the text in the clicked field
                textBox.Clear();

                // Set the active text box
                activeTextBox = textBox;

                // Reset the background color of all text boxes
                foreach (Control control in this.Controls)
                {
                    if (control is TextBox tb)
                    {
                        tb.BackColor = System.Drawing.Color.White;
                    }
                }
                
                // Highlight the active text box
                activeTextBox.BackColor = System.Drawing.Color.SkyBlue;

                // Position the keypad relative to the text box
                var textBoxPosition = this.PointToScreen(textBox.Location);
                int x = textBoxPosition.X + textBox.Width + 10; // Place keypad to the right of the text box
                int y = textBoxPosition.Y - 150; // Slightly above the field

                numKeypad.Location = new System.Drawing.Point(x, y);

                // Show the keypad
                numKeypad.Show();
            }
        }

        private bool ValidateAllFields()
        {
            bool isValid = true;
            StringBuilder errorMessages = new StringBuilder();

            foreach (Control control in this.Controls)
            {
                if (control is TextBox textBox)
                {
                    // Log for debugging purposes
                    Debug.WriteLine($"Validating: {textBox.Name}, Value: '{textBox.Text}'");

                    string value = textBox.Text;

                    if (textBox == txtGPATarget)
                    {
                        if (currentUnit == "I")
                        {
                            // Validate Imperial
                            if (!decimal.TryParse(value, out decimal gpa) || gpa < 0 || gpa > 30)
                            {
                                isValid = false;
                                textBox.BackColor = Color.LightCoral;
                                errorMessages.AppendLine("GPA Target must be a number between 0 and 30 GPA.");
                            }
                            else
                            {
                                textBox.BackColor = Color.White;
                            }
                        }
                        else
                        {
                            // Validate Metric
                            if (!decimal.TryParse(value, out decimal gpaMetric) || gpaMetric < 0 || gpaMetric > (30 * 9.35m))
                            {
                                isValid = false;
                                textBox.BackColor = Color.LightCoral;
                                errorMessages.AppendLine($"GPA Target must be a number between 0 and {(30 * 9.35m):F2} Liters/Ha.");
                            }
                            else
                            {
                                textBox.BackColor = Color.White;
                            }
                        }
                    }
                    if (textBox == txtPressureTarget)
                    {
                        if (currentUnit == "I")
                        {
                            // Validate Imperial
                            if (!decimal.TryParse(value, out decimal pressure) || pressure < 0 || pressure > 100)
                            {
                                isValid = false;
                                textBox.BackColor = Color.LightCoral;
                                errorMessages.AppendLine("Pressure Target must be a number between 0 and 100 PSI.");
                            }
                            else
                            {
                                textBox.BackColor = Color.White;
                            }
                        }
                        else
                        {
                            // Validate Metric
                            if (!decimal.TryParse(value, out decimal pressureMetric) || pressureMetric < 0 || pressureMetric > (100 * 6.895m))
                            {
                                isValid = false;
                                textBox.BackColor = Color.LightCoral;
                                errorMessages.AppendLine($"Pressure Target must be a number between 0 and {(100 * 6.895m):F2} kPa.");
                            }
                            else
                            {
                                textBox.BackColor = Color.White;
                            }
                        }
                    }
                    // Continue adding validations for other fields similarly...
                    if (textBox == txtBall_Hyd)
                    {
                        if (string.IsNullOrWhiteSpace(textBox.Text) || !decimal.TryParse(textBox.Text, out decimal BH) || BH < 0 || BH > 1)
                        {
                            isValid = false;
                            textBox.BackColor = System.Drawing.Color.LightCoral;
                            errorMessages.AppendLine($"Ball Hydraulics: Enter a number between 0 and 1. (You entered: '{textBox.Text}')");
                        }
                        else
                        {
                            textBox.BackColor = System.Drawing.Color.White;
                        }
                    }
                    if (textBox == txtSprayWidth)
                    {
                        if (currentUnit == "I")
                        {
                            // Validate Imperial
                            if (!decimal.TryParse(value, out decimal sprayWidth) || sprayWidth < 0 || sprayWidth > 45)
                            {
                                isValid = false;
                                textBox.BackColor = Color.LightCoral;
                                errorMessages.AppendLine("Spray Width must be a number between 0 and 45 feet.");
                            }
                            else
                            {
                                textBox.BackColor = Color.White;
                            }
                        }
                        else
                        {
                            // Validate Metric
                            if (!decimal.TryParse(value, out decimal sprayWidthMetric) || sprayWidthMetric < 0 || sprayWidthMetric > (45 * 0.3048m))
                            {
                                isValid = false;
                                textBox.BackColor = Color.LightCoral;
                                errorMessages.AppendLine($"Spray Width must be a number between 0 and {(45 * 0.3048m):F2} meters.");
                            }
                            else
                            {
                                textBox.BackColor = Color.White;
                            }
                        }
                    }
                }
            }

            if (!isValid)
            {
                MessageBox.Show(errorMessages.ToString(), "Validation Errors", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            return isValid;
        }

        private void NumKeypad_ButtonPressed(object sender, KeyPressEventArgs e)
        {
            if (activeTextBox == null) return;

            char key = e.KeyChar;

            switch (key)
            {
                case 'C': // Clear the input
                    activeTextBox.Text = "";
                    break;

                case 'B': // Backspace
                    if (activeTextBox.Text.Length > 0)
                    {
                        activeTextBox.Text = activeTextBox.Text.Substring(0, activeTextBox.Text.Length - 1);
                    }
                    break;

                case 'K': // OK - Validate and finalize input
                    if (ValidateInput(activeTextBox.Text))
                    {
                        numKeypad.Hide();
                        activeTextBox = null; // Clear the active text box
                    }
                    break;

                case 'X': // Cancel
                    numKeypad.Hide();
                    activeTextBox = null;
                    break;

                case '-': // Toggle positive/negative sign
                    if (!string.IsNullOrEmpty(activeTextBox.Text))
                    {
                        // If the value is negative, remove the '-' sign
                        if (activeTextBox.Text.StartsWith("-"))
                        {
                            activeTextBox.Text = activeTextBox.Text.Substring(1);
                        }
                        else
                        {
                            // Add the '-' sign if not already negative
                            activeTextBox.Text = "-" + activeTextBox.Text;
                        }
                    }
                    else
                    {
                        // If the field is empty, start with a negative sign
                        activeTextBox.Text = "-";
                    }
                    break;


                default: // Append numeric input
                    if (char.IsDigit(key) || key == '.')
                    {
                        if (key == '.' && activeTextBox.Text.Contains(".")) return; // Prevent multiple decimals
                        activeTextBox.Text += key;
                    }
                    break;
            }
        }

        private bool ValidateInput(string input)
        {
            if (activeTextBox == null) return true; // No active field to validate

            switch (activeTextBox.Name)
            {
                case "txtGPATarget":
                    if (currentUnit == "I")
                    {
                        // Validate Imperial
                        if (!decimal.TryParse(input, out decimal gpa) || gpa < 0 || gpa > 30)
                        {
                            ShowValidationError("GPA Target must be a number between 0 and 30 GPA.");
                            return false;
                        }
                    }
                    else
                    {
                        // Validate Metric
                        if (!decimal.TryParse(input, out decimal gpaMetric) || gpaMetric < 0 || gpaMetric > (30 * 9.35m))
                        {
                            ShowValidationError($"GPA Target must be a number between 0 and {(30 * 9.35m):F2} Liters/Ha.");
                            return false;
                        }
                    }
                    break;

                case "txtPressureTarget":
                    if (currentUnit == "I")
                    {
                        // Validate Imperial
                        if (!decimal.TryParse(input, out decimal pressure) || pressure < 0 || pressure > 100)
                        {
                            ShowValidationError("Pressure Target must be a number between 0 and 100 PSI.");
                            return false;
                        }
                    }
                    else
                    {
                        // Validate Metric
                        if (!decimal.TryParse(input, out decimal pressureMetric) || pressureMetric < 0 || pressureMetric > (100 * 6.895m))
                        {
                            ShowValidationError($"Pressure Target must be a number between 0 and {(100 * 6.895m):F2} kPa.");
                            return false;
                        }
                    }
                    break;

                case "txtFlowCalibration":
                    if (!decimal.TryParse(input, out decimal flow) || flow <= 0)
                    {
                        ShowValidationError("Flow Calibration must be a positive number greater than 0.");
                        return false;
                    }
                    break;

                case "txtPSICalibration":
                    if (!decimal.TryParse(input, out decimal psi) || psi < 0 || psi > 10)
                    {
                        ShowValidationError("PSI Calibration must be a number between 0 and 10.");
                        return false;
                    }
                    break;

                case "txtDutyCycleAdjustment":
                    if (!decimal.TryParse(input, out decimal dca) || dca < 0 || dca > 5)
                    {
                        ShowValidationError("Duty Cycle Adjustment must be a number between 0 and 5.");
                        return false;
                    }
                    break;

                case "txtnumberNozzles":
                    if (!decimal.TryParse(input, out decimal nozzles) || nozzles < 0 || nozzles > 100)
                    {
                        ShowValidationError("Number of Nozzles must be a number between 0 and 100.");
                        return false;
                    }
                    break;

                case "txtcurrentDutyCycle":
                    if (!decimal.TryParse(input, out decimal dutyCycle) || dutyCycle < 0 || dutyCycle > 100)
                    {
                        ShowValidationError("Current Duty Cycle must be a number between 0 and 100.");
                        return false;
                    }
                    break;

                case "txtHz":
                    if (!decimal.TryParse(input, out decimal hz) || hz < 1 || hz > 30)
                    {
                        ShowValidationError("Hz must be a number between 1 and 30.");
                        return false;
                    }
                    break;

                case "txtLowBallValve":
                    if (!decimal.TryParse(input, out decimal lowValve) || lowValve < 0 || lowValve > 40)
                    {
                        ShowValidationError("Low Ball Valve must be a number between 0 and 40.");
                        return false;
                    }
                    break;

                case "txtBall_Hyd":
                    if (!decimal.TryParse(input, out decimal ballHyd) || ballHyd < 0 || ballHyd > 1)
                    {
                        ShowValidationError("Ball Hydraulics must be 0 for Hyd and 1 for ball valve.");
                        return false;
                    }
                    break;

                case "txtWheelAngle":
                    if (!decimal.TryParse(input, out decimal wheelAngle) || wheelAngle < 0 || wheelAngle > 10)
                    {
                        ShowValidationError("Wheel Angle must be a number between 0 and 10.");
                        return false;
                    }
                    break;

                case "txtKp":
                    if (!decimal.TryParse(input, out decimal kp) || kp < 0 || kp > 5)
                    {
                        ShowValidationError("Kp must be a number between 0 and 5.");
                        return false;
                    }
                    break;

                case "txtKi":
                    if (!decimal.TryParse(input, out decimal ki) || ki < 0 || ki > 5)
                    {
                        ShowValidationError("Ki must be a number between 0 and 5.");
                        return false;
                    }
                    break;

                case "txtKd":
                    if (!decimal.TryParse(input, out decimal kd) || kd < 0 || kd > 5)
                    {
                        ShowValidationError("Kd must be a number between 0 and 5.");
                        return false;
                    }
                    break;

                case "txtSprayWidth":
                    if (currentUnit == "I")
                    {
                        // Validate Imperial
                        if (!decimal.TryParse(input, out decimal sprayWidth) || sprayWidth < 0 || sprayWidth > 45)
                        {
                            ShowValidationError("Spray Width must be a number between 0 and 45 feet.");
                            return false;
                        }
                    }
                    else
                    {
                        // Validate Metric
                        if (!decimal.TryParse(input, out decimal sprayWidthMetric) || sprayWidthMetric < 0 || sprayWidthMetric > (45 * 0.3048m))
                        {
                            ShowValidationError($"Spray Width must be a number between 0 and {(45 * 0.3048m):F2} meters.");
                            return false;
                        }
                    }
                    break;

                default:
                    // No validation rule defined for this field
                    return true;
            }

            return true; // Input is valid
        }

        private void ShowValidationError(string message)
        {
            MessageBox.Show(message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            activeTextBox.BackColor = System.Drawing.Color.LightCoral; // Highlight field
            activeTextBox.Focus(); // Keep focus on the invalid field
        }

        private void PopulateDebugLevelComboBox()
        {
            // Populate ComboBox with debug level options (0 to 12)
            for (int i = 0; i <= 12; i++)
            {
                cmbDebugPwmLevel.Items.Add($"{i} - {GetDebugLevelDescription(i)}");
            }
            cmbDebugPwmLevel.SelectedIndex = 0; // Default selection
        }

        private string GetDebugLevelDescription(int level)
        {
            return level switch
            {
                0 => "debug - Turns OFF all reporting",
                1 => "dutycycleTurncomp - Individual nozzle reporting",
                2 => "setPWMTiming - Sets timing of nozzle on cycle",
                3 => "ControlNozzle - Controls nozzle (not used in a turn)",
                4 => "Pressure - System pressure",
                5 => "EvenOdd - Toggle firing of even/odd nozzles",
                6 => "Flow - Flow rate control",
                7 => "NozzleSpeed - Individual nozzle speed in a turn",
                8 => "PrintDebug - Overall system reporting",
                9 => "PrintAOG - Reports variables passed from AOG",
                10 => "Calibrate_PSI_Flow - Calibration function",
                11 => "ActualSteerAngle - extractActualSteerAngle",
                12 => "Communication - Debug UDP",
                _ => "Unknown"
            };
        }


        private void StartListening()
        {
            udpClient.BeginReceive(OnDataReceived, null);

        }


        private void OnDataReceived(IAsyncResult ar)
        {
            try
            {

                var data = udpClient.EndReceive(ar, ref arduinoEndPoint);
                string receivedData = Encoding.UTF8.GetString(data);

                Debug.WriteLine("Received Data: " + receivedData); // Log the raw received data

                if (receivedData.StartsWith("USER_SETTINGS:"))
                {
                    Debug.WriteLine("Processing USER_SETTINGS data.");
                    UpdateUserSettings(receivedData.Replace("USER_SETTINGS:", ""));
                }
                else if (receivedData.StartsWith("SENSOR_DATA:"))
                {
                    Debug.WriteLine("Processing SENSOR_DATA.");
                    UpdateUI(receivedData.Replace("SENSOR_DATA:", ""));
                }
                else
                {
                    Debug.WriteLine("Unrecognized data format.");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error receiving data: " + ex.Message);
            }
            finally
            {
                StartListening(); // Restart listening
            }
        }


        private void UpdateUserSettings(string data)
        {
            string[] variables = data.Split(',');
            foreach (var variable in variables)
            {
                var parts = variable.Split(':');
                if (parts.Length != 2) continue;

                string name = parts[0].Trim();
                string value = parts[1].Trim();

                Debug.WriteLine($"Updating setting: {name} = {value}"); // Log each setting update

                Invoke((MethodInvoker)delegate
                {
                    switch (name)
                    {
                        case "GPATarget": txtGPATarget.Text = value; break;
                        case "SprayWidth": txtSprayWidth.Text = value; break;
                        case "FlowCalibration": txtFlowCalibration.Text = value; break;
                        case "PSICalibration": txtPSICalibration.Text = value; break;
                        case "DutyCycleAdjustment": txtDutyCycleAdjustment.Text = value; break;
                        case "PressureTarget": txtPressureTarget.Text = value; break;
                        case "numberNozzles": txtnumberNozzles.Text = value; break;
                        case "currentDutyCycle": txtcurrentDutyCycle.Text = value; break;
                        case "Hz": txtHz.Text = value; break;
                        case "LowBallValve": txtLowBallValve.Text = value; break;
                        case "Ball_Hyd": txtBall_Hyd.Text = value; break;
                        case "WheelAngle": txtWheelAngle.Text = value; break;
                        case "Kp": txtKp.Text = value; break;
                        case "Ki": txtKi.Text = value; break;
                        case "Kd": txtKd.Text = value; break;
                        case "Unit":
                            {
                                // Map "I" to "I - Imperial" and "M" to "M - Metric"
                                string newUnit = value == "I" ? "I - Imperial" : "M - Metric";

                                Debug.WriteLine($"[DEBUG] Received Unit: {value}, Interpreted Unit: {newUnit}, Current Unit: {currentUnit}");

                                // Prevent triggering SelectedIndexChanged unnecessarily
                                if (CmbUnits.SelectedItem == null || CmbUnits.SelectedItem.ToString() != newUnit)
                                {
                                    CmbUnits.SelectedIndexChanged -= CmbUnits_SelectedIndexChanged;
                                    CmbUnits.SelectedIndex = value == "I" ? 0 : 1;
                                    CmbUnits.SelectedIndexChanged += CmbUnits_SelectedIndexChanged;

                                    Debug.WriteLine($"[DEBUG] Updated Dropdown to: {CmbUnits.SelectedItem}, Updated Current Unit: {currentUnit}");
                                }

                                // Update the current unit
                                currentUnit = value;
                                break;
                            }
                        case "PWM_Conventional":
                            chkPWM_Conventional.Checked = value == "1";
                            break;
                        case "Stagger":
                            chkStagger.Checked = value == "1";
                            break;
                        case "debug":
                            cmbDebugPwmLevel.SelectedIndex = int.TryParse(value, out int debugLevel) ? debugLevel : 0;
                            break;
                            Debug.WriteLine($"Set debugPwmLevel to: {cmbDebugPwmLevel.SelectedIndex}");
                        default:
                            Debug.WriteLine($"Unrecognized field: {name}");
                            break;
                    }
                });
            }
        }

        private void UpdateUI(string data)
        {
            string[] variables = data.Split(',');
            foreach (var variable in variables)
            {
                var parts = variable.Split(':');
                if (parts.Length != 2) continue;

                string name = parts[0].Trim();
                string value = parts[1].Trim();

                Invoke((MethodInvoker)delegate
                {
                    switch (name)
                    {
                        case "pressure":
                            if (decimal.TryParse(value, out decimal pressure))
                            {
                                if (currentUnit == "M")
                                {
                                    // Convert PSI to kPa
                                    value = (pressure * 6.895m).ToString("F2");
                                }
                                txtpressure.Text = value; // Update the UI field
                            }
                            break;

                        case "gpsSpeed":
                            if (decimal.TryParse(value, out decimal speed))
                            {
                                if (currentUnit == "M")
                                {
                                    // Convert MPH to KPH
                                    value = (speed * 1.609m).ToString("F2");
                                }
                                txtgpsSpeed.Text = value; // Update the UI field
                            }
                            break;

                        case "actualGPAave":
                            if (decimal.TryParse(value, out decimal gpa))
                            {
                                if (currentUnit == "M")
                                {
                                    // Convert GPA to Liters/Ha
                                    value = (gpa * 9.35m).ToString("F2");
                                }
                                txtactualGPAave.Text = value; // Update the UI field
                            }
                            break;

                        case "onTime":
                            // onTime is unitless, no conversion needed
                            txtonTime.Text = value;
                            break;

                        // Add more cases as needed for additional sensor data fields

                        default:
                            Debug.WriteLine($"Unrecognized sensor data: {name} = {value}");
                            break;
                    }
                });
            }
        }



        private string ParseValue(string settings, string fieldName)
        {
            var match = Regex.Match(settings, $"{fieldName}:(\\d+(\\.\\d+)?)");
            return match.Success ? match.Groups[1].Value : "0";
        }


        private void SendButton_Click(object sender, EventArgs e)
        {
            string message = GenerateSettingsMessage();
            byte[] bytes = Encoding.UTF8.GetBytes(message);
            udpClient.Send(bytes, bytes.Length, arduinoEndPoint);
        }

        private string GenerateSettingsMessage()
        {
            Debug.WriteLine($"[DEBUG] Current Unit before Sending Settings: {currentUnit}");

            string gpa = string.IsNullOrWhiteSpace(txtGPATarget.Text) ? "0" : txtGPATarget.Text;
            string sprayWidth = string.IsNullOrWhiteSpace(txtSprayWidth.Text) ? "0" : txtSprayWidth.Text;
            string flowCalibration = string.IsNullOrWhiteSpace(txtFlowCalibration.Text) ? "0" : txtFlowCalibration.Text;
            string psiCalibration = string.IsNullOrWhiteSpace(txtPSICalibration.Text) ? "0" : txtPSICalibration.Text;
            string dutyCycleAdjustment = string.IsNullOrWhiteSpace(txtDutyCycleAdjustment.Text) ? "0" : txtDutyCycleAdjustment.Text;
            string pressureTarget = string.IsNullOrWhiteSpace(txtPressureTarget.Text) ? "0" : txtPressureTarget.Text;
            string numberNozzles = string.IsNullOrWhiteSpace(txtnumberNozzles.Text) ? "0" : txtnumberNozzles.Text;
            string currentDutyCycle = string.IsNullOrWhiteSpace(txtcurrentDutyCycle.Text) ? "0" : txtcurrentDutyCycle.Text;
            string hz = string.IsNullOrWhiteSpace(txtHz.Text) ? "0" : txtHz.Text;
            string lowBallValve = string.IsNullOrWhiteSpace(txtLowBallValve.Text) ? "0" : txtLowBallValve.Text;
            string ballHyd = string.IsNullOrWhiteSpace(txtBall_Hyd.Text) ? "0" : txtBall_Hyd.Text;
            string wheelAngle = string.IsNullOrWhiteSpace(txtWheelAngle.Text) ? "0" : txtWheelAngle.Text;
            string kp = string.IsNullOrWhiteSpace(txtKp.Text) ? "0" : txtKp.Text;
            string ki = string.IsNullOrWhiteSpace(txtKi.Text) ? "0" : txtKi.Text;
            string kd = string.IsNullOrWhiteSpace(txtKd.Text) ? "0" : txtKd.Text;
            string unit = CmbUnits.SelectedItem.ToString().StartsWith("I") ? "I" : "M"; // Send "I" for Imperial, "M" for Metric
            string pwmConventional = chkPWM_Conventional.Checked ? "1" : "0";
            string stagger = chkStagger.Checked ? "1" : "0";
            string debugPwmLevel = cmbDebugPwmLevel.SelectedIndex.ToString();

            string settingsMessage = $"UPDATE_SETTINGS:GPATarget:{gpa}," +
                                     $"SprayWidth:{sprayWidth},FlowCalibration:{flowCalibration}," +
                                     $"PSICalibration:{psiCalibration},DutyCycleAdjustment:{dutyCycleAdjustment}," +
                                     $"PressureTarget:{pressureTarget},numberNozzles:{numberNozzles}," +
                                     $"currentDutyCycle:{currentDutyCycle},Hz:{hz},LowBallValve:{lowBallValve}," +
                                     $"Ball_Hyd:{ballHyd},WheelAngle:{wheelAngle},Kp:{kp}," +
                                     $"Ki:{ki},Kd:{kd},Unit:{unit},PWM_Conventional:{pwmConventional}," +
                                     $"Stagger:{stagger},debug:{debugPwmLevel}";

            Debug.WriteLine($"Generated Settings Message: {settingsMessage}");
            return settingsMessage;
        }


        private void SendDefaultSettings()
        {
            try
            {
                // Use the GenerateSettingsMessage method to construct default settings
                string defaultSettings = GenerateSettingsMessage();
                byte[] bytes = Encoding.UTF8.GetBytes(defaultSettings);

                udpClient.Send(bytes, bytes.Length, arduinoEndPoint);
                Debug.WriteLine("Default settings have been sent.");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error sending default settings: " + ex.Message);
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            System.Threading.Thread.Sleep(1000); // Wait 1 second before sending requests

            // Request user settings from the Teensy
            Debug.WriteLine("Sending REQUEST_USER_SETTINGS...");
            RequestDataFromTeensy("REQUEST_USER_SETTINGS");

            System.Threading.Thread.Sleep(500); // Wait 1/2 second before sending requests

            // Request sensor data from the Teensy
            Debug.WriteLine("Sending REQUEST_SENSOR_DATA...");
            RequestDataFromTeensy("REQUEST_SENSOR_DATA");

            this.Size = new System.Drawing.Size(400, 450); // Width = 400, Height = 450
            BtnToggleView.Image = SprayerControl_2._4.Properties.Resources.Next; // Set initial button image to "Next"

            // Initialize the sprayer control button
            BtnSprayerControl.Text = "Start"; // Initial text
            BtnSprayerControl.BackColor = System.Drawing.Color.Red; // Initial color
            isSprayerOn = false; // Ensure the sprayer is off at startup

            // Initialize chkStagger text based on its Checked state
            chkStagger.Text = chkStagger.Checked ? "Staggered" : "Not Staggered";

            // Similarly, initialize chkPWM_Conventional text
            chkPWM_Conventional.Text = chkPWM_Conventional.Checked ? "PWM Mode" : "Conventional Mode";

            // Clear and populate ComboBox with "Imperial" and "Metric"
            Debug.WriteLine("[DEBUG] Initializing Form...");
            CmbUnits.Items.Clear();
            CmbUnits.Items.Add("I - Imperial");
            CmbUnits.Items.Add("M - Metric");

            // Dynamically select the saved unit
            if (CmbUnits.Items.Count > 0)
            {
                CmbUnits.SelectedIndex = 0; // Default to the first item
                Debug.WriteLine($"[DEBUG] Default Unit Set to: {CmbUnits.SelectedItem}");
            }

            // Subscribe to events after setting initial value
            CmbUnits.SelectedIndexChanged += CmbUnits_SelectedIndexChanged;
        }


        private void RequestDataFromTeensy(string requestType)
        {
            try
            {
                byte[] requestBytes = Encoding.UTF8.GetBytes(requestType);
                udpClient.Send(requestBytes, requestBytes.Length, arduinoEndPoint);
                Debug.WriteLine($"Sent request: {requestType}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error sending request to Teensy: " + ex.Message);
            }
        }

        private void HelpButton_Click(object sender, EventArgs e)
        {
            // Create an instance of HelpForm
            HelpForm helpForm = new HelpForm();
            // Show the HelpForm as a modal dialog
            helpForm.ShowDialog();
        }

        private bool settingsSent = false;

        private void SendSettings_Click(object sender, EventArgs e)
        {
            // Validate all fields before submission
            if (ValidateAllFields())
            {
                try
                {
                    string message = GenerateSettingsMessage();
                    Debug.WriteLine("Generated Settings Message: " + message); // Log the generated message
                    byte[] bytes = Encoding.UTF8.GetBytes(message);

                    // I know I shouldn't have to do this, but I can't find where the port is getting changed to 8888
                    arduinoEndPoint = new IPEndPoint(IPAddress.Parse("192.168.5.123"), 7777);
                    Debug.WriteLine($"Enforcing arduinoEndPoint: {arduinoEndPoint.Address}:{arduinoEndPoint.Port}");
                    udpClient.Send(bytes, bytes.Length, arduinoEndPoint);
                    settingsSent = true; // Mark settings as sent

                    Debug.WriteLine("Settings have been sent successfully.");
                    MessageBox.Show("Settings have been sent successfully.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Error sending settings: " + ex.Message);
                    MessageBox.Show($"Error sending settings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Validation failed; do not proceed
                MessageBox.Show("Please correct the highlighted fields and try again.", "Validation Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private bool isExpanded = false; // Track the current state of the form

        private void BtnToggleView_Click(object sender, EventArgs e)
        {
            if (isExpanded)
            {
                // Switch to compact view
                this.Size = new System.Drawing.Size(400, 450); // Compact size W, H
                BtnToggleView.Image = SprayerControl_2._4.Properties.Resources.Next; // Change button image to "Next"
            }
            else
            {
                // Switch to expanded view
                this.Size = new System.Drawing.Size(900, 450); // Expanded size W, H
                BtnToggleView.Image = SprayerControl_2._4.Properties.Resources.Previous; // Change button image to "Previous"
            }

            // Toggle the state
            isExpanded = !isExpanded;
        }

        private bool isSprayerOn = false; // Track the current state of the sprayer

        private void BtnSprayerControl_Click(object sender, EventArgs e)
        {
            // Ensure settings are sent before toggling the sprayer
            if (!settingsSent) // Use a flag to track if settings were sent
            {
                Debug.WriteLine("Settings not sent. Sending default settings...");
                SendDefaultSettings();
                settingsSent = true;
            }

            // Toggle the sprayer state
            isSprayerOn = !isSprayerOn;

            // Update the button text to reflect the current state
            BtnSprayerControl.Text = isSprayerOn ? "Stop" : "Start";
            BtnSprayerControl.BackColor = isSprayerOn ? Color.Green : Color.Red;

            // Construct the command to send
            string command = isSprayerOn ? "START_SPRAYER" : "STOP_SPRAYER";
          
            try
            {
                arduinoEndPoint = new IPEndPoint(IPAddress.Parse("192.168.5.123"), 7777);
                Debug.WriteLine($"Enforcing arduinoEndPoint: {arduinoEndPoint.Address}:{arduinoEndPoint.Port}");

                // Send the command via UDP
                byte[] commandBytes = Encoding.UTF8.GetBytes(command);
                udpClient.Send(commandBytes, commandBytes.Length, arduinoEndPoint);

                Debug.WriteLine($"Sprayer command sent: {command}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error sending sprayer command: " + ex.Message);
            }
        }


        private void ChkPWM_Conventional_CheckedChanged(object sender, EventArgs e)
        {
            // Change the text based on the Checked state
            chkPWM_Conventional.Text = chkPWM_Conventional.Checked ? "PWM Mode" : "Conventional Mode";
        }

        private void ChkStagger_CheckedChanged(object sender, EventArgs e)
        {
            // Change the text based on the Checked state
            chkStagger.Text = chkStagger.Checked ? "Staggered" : "Not Staggered";
        }

        private string currentUnit = "I"; // Default to Imperial

        private void ConvertToMetric()
        {
            if (decimal.TryParse(txtGPATarget.Text, out decimal gpa))
            {
                txtGPATarget.Text = (gpa * 9.35m).ToString("F2"); // Example: GPA to Liters/Ha
            }

            if (decimal.TryParse(txtPressureTarget.Text, out decimal pressure))
            {
                txtPressureTarget.Text = (pressure * 6.895m).ToString("F2"); // PSI to kPa
            }

            // Add similar conversions for other fields
        }

        private void ConvertToImperial()
        {
            if (decimal.TryParse(txtGPATarget.Text, out decimal gpa))
            {
                txtGPATarget.Text = (gpa / 9.35m).ToString("F2"); // Liters/Ha to GPA
            }

            if (decimal.TryParse(txtPressureTarget.Text, out decimal pressure))
            {
                txtPressureTarget.Text = (pressure / 6.895m).ToString("F2"); // kPa to PSI
            }

            // Add similar conversions for other fields
        }


        private void CmbUnits_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CmbUnits.SelectedItem != null)
            {
                string selectedUnit = CmbUnits.SelectedItem.ToString();
                string newUnit = selectedUnit.StartsWith("M") ? "M" : "I";

                Debug.WriteLine($"[DEBUG] Dropdown Selection Changed: {selectedUnit}, Interpreted as: {newUnit}");

                // Only proceed if the unit has truly changed
                if (newUnit != currentUnit)
                {
                    currentUnit = newUnit;
                    Debug.WriteLine($"[DEBUG] Unit Change Detected: New Unit = {currentUnit}");

                    if (currentUnit == "M")
                    {
                        ConvertToMetric();
                    }
                    else
                    {
                        ConvertToImperial();
                    }
                }
                else
                {
                    Debug.WriteLine($"[DEBUG] No Unit Change Detected: Current Unit = {currentUnit}");
                }
            }
        }
    }
}


