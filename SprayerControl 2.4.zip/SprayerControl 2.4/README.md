# SprayerControl 2.4

Control app for PWM_Sprayer_Teensy_Code. This is a companion app to Ag Open GPS.  To learn more https://discourse.agopengps.com/  Communication is via UDP between this app and the teensy 4.1.